export const config = {
  useSupabase: false, // Toggle between mock data and Supabase
  mockUser: {
    email: "admin@topbest.vn",
    password: "123456",
  },
}
